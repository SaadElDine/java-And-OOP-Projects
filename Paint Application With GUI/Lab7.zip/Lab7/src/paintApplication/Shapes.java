/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paintApplication;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/**
 *
 * @author Saad
 */

public abstract class Shapes implements Shape {
   
    private Point position;
    private Color color;
    private Color fillColor;
    private String name;
    
    public Shapes(String name, Point position, Color color, Color fillColor) {
        
        this.name = name;
        this.setPosition(position);
        this.setColor(color);
        this.setFillColor(fillColor);
    }
    
    @Override
    public void setPosition(Point point1) {
        this.position = point1;
    }

    @Override
    public Point getPosition() {
        return this.position;
    }

    @Override
    public void setColor(Color color) {
        this.color = color;
    }

    @Override
    public Color getColor() {
        return this.color;
    }

    @Override
    public void setFillColor(Color color) {
        this.fillColor = color;
    }

    @Override
    public Color getFillColor() {
        return this.fillColor;
    }

    @Override
    public void draw(Graphics canvas) {}
    
}
