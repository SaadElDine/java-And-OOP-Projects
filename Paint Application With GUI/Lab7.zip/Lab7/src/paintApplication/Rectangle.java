/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paintApplication;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/**
 *
 * @author Saad
 */

public class Rectangle extends Shapes{
    
    private int width;
    private int height;

    public Rectangle(int width, int height, String name, Point position, Color color, Color fillColor) {
        super(name, position, color, fillColor);
        this.width = width;
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
    
    @Override
    public void draw(Graphics canvas) {
        
        if (this.getFillColor() != null) {
            canvas.setColor(this.getFillColor());
            canvas.fillRect(getPosition().x, getPosition().y, this.width, this.height);
        }

        canvas.setColor(this.getColor());
        canvas.drawRect(getPosition().x, getPosition().y, this.width, this.height);  
    }  
}
