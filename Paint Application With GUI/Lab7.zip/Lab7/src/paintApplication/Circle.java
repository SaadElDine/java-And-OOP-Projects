/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paintApplication;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/**
 *
 * @author Saad
 */

public class Circle extends Shapes {
    
    private int radius;

    public Circle(int radius , String name, Point position, Color color, Color fillColor) {
        super(name, position, color, fillColor);
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }
   
    @Override
    public void draw(Graphics canvas) {
        if (this.getFillColor() != null) {
            canvas.setColor(this.getFillColor());
            canvas.fillOval(getPosition().x, getPosition().y, this.radius, this.radius);
        }
        
        canvas.setColor(this.getColor());
        canvas.drawOval(getPosition().x, getPosition().y, this.radius, this.radius);  
    }
}
