/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package paintApplication;
import java.awt.*;


/**
 *
 * @author Saad
 */

public class LineSegment extends Shapes {

    private Point point2;
  
    public LineSegment (String name, Point position, Color color, Color fillColor, Point point2) {
        super(name, position, color, fillColor);
        this.point2 = point2;
    }
   
    @Override
    public void draw(Graphics canvas) {
        canvas.setColor(this.getColor());
        canvas.drawLine(getPosition().x, getPosition().y, this.point2.x, this.point2.y);  
    }
}
